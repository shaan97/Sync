var searchData=
[
  ['rbegin',['rbegin',['../classnlohmann_1_1basic__json.html#a1ef93e2006dbe52667294f5ef38b0b10',1,'nlohmann::basic_json::rbegin() noexcept'],['../classnlohmann_1_1basic__json.html#a515e7618392317dbf4b72d3e18bf2ab2',1,'nlohmann::basic_json::rbegin() const noexcept']]],
  ['read',['read',['../classshaan97_1_1sync_1_1_member.html#a258cd0c6ae7617ce17f7a36e78b95b85',1,'shaan97::sync::Member::read(Buffer b, std::size_t len, Error &amp;e) const'],['../classshaan97_1_1sync_1_1_member.html#ab45388cff5245ca5afc2945a000b23ab',1,'shaan97::sync::Member::read(Buffer b, Error &amp;e) const'],['../classshaan97_1_1sync_1_1_member.html#a58a9c4dad0338a4101ed36ee710ed8f2',1,'shaan97::sync::Member::read(Buffer b, size_t len, Error &amp;e) const']]],
  ['reallimits',['RealLimits',['../structnlohmann_1_1detail_1_1is__compatible__integer__type__impl_3_01true_00_01_real_integer_type78b0ba77f36a8c8169cdb79b01d1a4bf.html#a1bad172320cd124997a3d68990f50a75',1,'nlohmann::detail::is_compatible_integer_type_impl&lt; true, RealIntegerType, CompatibleNumberIntegerType &gt;']]],
  ['reference',['reference',['../classnlohmann_1_1basic__json.html#ac6a5eddd156c776ac75ff54cfe54a5bc',1,'nlohmann::basic_json::reference()'],['../classnlohmann_1_1basic__json_1_1iter__impl.html#ae09599e9cb4a947020a0265c0c4f3d5e',1,'nlohmann::basic_json::iter_impl::reference()'],['../classnlohmann_1_1basic__json_1_1json__reverse__iterator.html#ab0021ef2007fd338615360af404dcd4e',1,'nlohmann::basic_json::json_reverse_iterator::reference()']]],
  ['reference_5ftokens',['reference_tokens',['../classnlohmann_1_1basic__json_1_1json__pointer.html#a04832c52ff9b4237ec15d437390f7637',1,'nlohmann::basic_json::json_pointer']]],
  ['rend',['rend',['../classnlohmann_1_1basic__json.html#ac77aed0925d447744676725ab0b6d535',1,'nlohmann::basic_json::rend() noexcept'],['../classnlohmann_1_1basic__json.html#a4f73d4cee67ea328d785979c22af0ae1',1,'nlohmann::basic_json::rend() const noexcept']]],
  ['replace_5fsubstring',['replace_substring',['../classnlohmann_1_1basic__json_1_1json__pointer.html#afc5dd65e2855e09f46bad1882b2b7ce0',1,'nlohmann::basic_json::json_pointer']]],
  ['resolveowner',['resolveOwner',['../classshaan97_1_1sync_1_1_group.html#a4925f72201a7c780581220aa404fdab9',1,'shaan97::sync::Group']]],
  ['resolver',['resolver',['../classshaan97_1_1sync_1_1_client.html#a6e2a1fef479966299280a231815ab6c9',1,'shaan97::sync::Client']]],
  ['reverse_5fiterator',['reverse_iterator',['../classnlohmann_1_1basic__json.html#ac223d5560c2b05a208c88de67376c5f2',1,'nlohmann::basic_json']]],
  ['run',['run',['../classshaan97_1_1sync_1_1_group.html#a916b46aaf2fecb3694089a83850f061a',1,'shaan97::sync::Group']]]
];
