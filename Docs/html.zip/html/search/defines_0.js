var searchData=
[
  ['default_5fport',['DEFAULT_PORT',['../_server_8h.html#a16b710f592bf8f7900666392adc444dc',1,'Server.h']]],
  ['default_5fversion',['DEFAULT_VERSION',['../_server_8h.html#a13dae059206df8d2d9b9b42e694b3f9c',1,'Server.h']]]
];
