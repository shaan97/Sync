var searchData=
[
  ['corrupted_5fdata',['CORRUPTED_DATA',['../namespaceshaan97_1_1sync.html#a69f4d5572314be52626f6a1c8ecc8db9aa848eafa9f1a60215e209859d3e687c4',1,'shaan97::sync']]]
];
