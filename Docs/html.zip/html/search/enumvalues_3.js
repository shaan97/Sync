var searchData=
[
  ['details',['DETAILS',['../namespaceshaan97_1_1sync.html#a475934f59b3e5af2cfdab7cd20942b6cac8e6b57e5b75aa7001876e5f86d05db4',1,'shaan97::sync']]],
  ['discarded',['discarded',['../namespacenlohmann_1_1detail.html#a90aa5ef615aa8305e9ea20d8a947980fa94708897ec9db8647dfe695714c98e46',1,'nlohmann::detail']]]
];
