var searchData=
[
  ['failed_5fconnection',['FAILED_CONNECTION',['../namespaceshaan97_1_1sync.html#a69f4d5572314be52626f6a1c8ecc8db9a826ca9fbc231462e0dae956a8fdc078b',1,'shaan97::sync']]]
];
