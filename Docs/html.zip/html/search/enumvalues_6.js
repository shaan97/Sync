var searchData=
[
  ['gid',['GID',['../namespaceshaan97_1_1sync.html#a475934f59b3e5af2cfdab7cd20942b6ca1a66b3a888f6bc7c1ab901824009f47c',1,'shaan97::sync']]],
  ['gid_5fexists',['GID_EXISTS',['../namespaceshaan97_1_1sync.html#a69f4d5572314be52626f6a1c8ecc8db9ac6c293b7f0506d3ee58658539e4e3fc0',1,'shaan97::sync']]],
  ['gid_5fno_5fexist',['GID_NO_EXIST',['../namespaceshaan97_1_1sync.html#a69f4d5572314be52626f6a1c8ecc8db9af4f2e82194c014add58de880aeb14bee',1,'shaan97::sync']]],
  ['group_5fcreate',['GROUP_CREATE',['../namespaceshaan97_1_1sync.html#a902024d98481afc28794167b4524f537ad852dfe5f29536b5807099fd5265d1ae',1,'shaan97::sync']]],
  ['group_5fexit',['GROUP_EXIT',['../namespaceshaan97_1_1sync.html#a902024d98481afc28794167b4524f537a8aea50566a25675d0046705e9c248521',1,'shaan97::sync']]],
  ['group_5fjoin',['GROUP_JOIN',['../namespaceshaan97_1_1sync.html#a902024d98481afc28794167b4524f537a04edc961a82f770aec6cb525f6d3e7e9',1,'shaan97::sync']]]
];
