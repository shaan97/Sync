var searchData=
[
  ['literal_5ffalse',['literal_false',['../classnlohmann_1_1basic__json_1_1lexer.html#a96887d6cd131e3d3a85a9d71fbdbcdf7afab1694b1b3937a079f4625fe0b6108b',1,'nlohmann::basic_json::lexer']]],
  ['literal_5fnull',['literal_null',['../classnlohmann_1_1basic__json_1_1lexer.html#a96887d6cd131e3d3a85a9d71fbdbcdf7ab7ae4c0e46d86f884677768160b26e9e',1,'nlohmann::basic_json::lexer']]],
  ['literal_5ftrue',['literal_true',['../classnlohmann_1_1basic__json_1_1lexer.html#a96887d6cd131e3d3a85a9d71fbdbcdf7a85cc1a37b0aaa52de40e72f0ed4e0c0d',1,'nlohmann::basic_json::lexer']]]
];
