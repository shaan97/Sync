var searchData=
[
  ['x_5fwrite',['x_write',['../structnlohmann_1_1basic__json_1_1numtostr.html#aadc027c4daff6c4a9fd51a58ff16e53c',1,'nlohmann::basic_json::numtostr::x_write(NumberType x, std::true_type)'],['../structnlohmann_1_1basic__json_1_1numtostr.html#a91a7a5b4311422f1ad298245501a05d1',1,'nlohmann::basic_json::numtostr::x_write(NumberType x, std::false_type)']]]
];
