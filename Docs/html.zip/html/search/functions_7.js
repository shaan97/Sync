var searchData=
[
  ['handle_5faccept',['handle_accept',['../group___connection_handling.html#ga447569609c9d667ab509e61d1dd1b476',1,'shaan97::sync::Server']]],
  ['handle_5fheartbeat',['handle_heartbeat',['../group___message_handling.html#ga56230c5225416d342206232d3f2b8f6e',1,'shaan97::sync::Server']]]
];
