var searchData=
[
  ['detail',['detail',['../namespacenlohmann_1_1detail.html',1,'nlohmann']]],
  ['nlohmann',['nlohmann',['../namespacenlohmann.html',1,'']]]
];
