var searchData=
[
  ['from_5fjson',['from_json',['../group___serialization.html#ga827d73b9e95e7aa59bf1b159251bedf3',1,'shaan97::sync::Error']]]
];
