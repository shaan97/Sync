var searchData=
[
  ['to_5fjson',['to_json',['../group___serialization.html#ga06e5a619d8d673a3bb00b006e62bbe1e',1,'shaan97::sync::Error']]]
];
