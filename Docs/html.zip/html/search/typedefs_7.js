var searchData=
[
  ['json',['json',['../namespacenlohmann.html#a2bfd99e845a2e5cd90aeaf1b1431f474',1,'nlohmann::json()'],['../_server_8cpp.html#ab701e3ac61a85b337ec5c1abaad6742d',1,'json():&#160;Server.cpp']]],
  ['json_5fserializer',['json_serializer',['../classnlohmann_1_1basic__json.html#a7768841baaaa7a21098a401c932efaff',1,'nlohmann::basic_json']]]
];
