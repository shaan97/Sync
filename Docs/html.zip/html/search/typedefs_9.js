var searchData=
[
  ['membername',['MemberName',['../namespaceshaan97_1_1sync.html#af59c2c9185f7cde547b79fbe0bf8ec71',1,'shaan97::sync']]]
];
