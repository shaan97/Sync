var searchData=
[
  ['object_5ft',['object_t',['../classnlohmann_1_1basic__json.html#aa1eb13d5aa86f80cbee6c58e90fbaf49',1,'nlohmann::basic_json']]]
];
