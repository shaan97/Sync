var searchData=
[
  ['last_5ftoken',['last_token',['../classnlohmann_1_1basic__json_1_1parser.html#ace0babedd22742bbb5f31d35d1d5baa9',1,'nlohmann::basic_json::parser']]],
  ['last_5ftoken_5ftype',['last_token_type',['../classnlohmann_1_1basic__json_1_1lexer.html#a2ad8bad3a2224be7fdd4e4bb0f757a0e',1,'nlohmann::basic_json::lexer']]]
];
