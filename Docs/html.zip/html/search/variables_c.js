var searchData=
[
  ['primitive_5fiterator',['primitive_iterator',['../structnlohmann_1_1basic__json_1_1internal__iterator.html#ac1938c3d3d3d713b68a7a82d7cb569eb',1,'nlohmann::basic_json::internal_iterator']]]
];
